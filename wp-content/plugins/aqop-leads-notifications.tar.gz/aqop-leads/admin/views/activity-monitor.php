<?php
/**
 * Activity Monitor Admin View
 *
 * @package AQOP_Leads
 * @since   1.1.0
 */

if (!defined('ABSPATH')) {
    exit;
}

// Check permissions
if (!current_user_can('manage_options') && !current_user_can('edit_others_posts')) {
    wp_die(__('You do not have sufficient permissions to access this page.', 'aqop-leads'));
}

// Get tracker instance
$tracker = new AQOP_Activity_Tracker();

// Handle actions
if (isset($_POST['aqop_action']) && $_POST['aqop_action'] === 'clear_history') {
    check_admin_referer('aqop_clear_history', 'aqop_nonce');
    $days = isset($_POST['days']) ? absint($_POST['days']) : 90;
    $deleted = $tracker->cleanup($days);
    echo '<div class="notice notice-success"><p>' . sprintf(__('History cleared. %d records deleted.', 'aqop-leads'), $deleted) . '</p></div>';
}

// Get filters
$filter_user = isset($_GET['user_id']) ? absint($_GET['user_id']) : 0;
$filter_type = isset($_GET['activity_type']) ? sanitize_text_field($_GET['activity_type']) : '';
$filter_search = isset($_GET['s']) ? sanitize_text_field($_GET['s']) : '';
$paged = isset($_GET['paged']) ? absint($_GET['paged']) : 1;
$limit = 20;
$offset = ($paged - 1) * $limit;

// Get logs
$logs_data = $tracker->get_logs(array(
    'user_id' => $filter_user,
    'activity_type' => $filter_type,
    'search' => $filter_search,
    'limit' => $limit,
    'offset' => $offset,
));

$logs = $logs_data['items'];
$total = $logs_data['total'];
$total_pages = ceil($total / $limit);

// Get unique activity types for filter
global $wpdb;
$types = $wpdb->get_col("SELECT DISTINCT activity_type FROM {$wpdb->prefix}aq_user_activity_log ORDER BY activity_type ASC");

?>

<div class="wrap">
    <h1 class="wp-heading-inline"><?php _e('Activity Monitor', 'aqop-leads'); ?></h1>

    <form method="post" style="display:inline-block; margin-left: 10px;">
        <?php wp_nonce_field('aqop_clear_history', 'aqop_nonce'); ?>
        <input type="hidden" name="aqop_action" value="clear_history">
        <input type="hidden" name="days" value="90">
        <button type="submit" class="button button-secondary"
            onclick="return confirm('<?php _e('Are you sure you want to delete logs older than 90 days?', 'aqop-leads'); ?>');">
            <?php _e('Clear Old History (> 90 days)', 'aqop-leads'); ?>
        </button>
    </form>

    <hr class="wp-header-end">

    <!-- Filters -->
    <form method="get">
        <input type="hidden" name="page" value="<?php echo esc_attr($_REQUEST['page']); ?>" />

        <div class="tablenav top">
            <div class="alignleft actions">
                <!-- Activity Type Filter -->
                <select name="activity_type">
                    <option value=""><?php _e('All Activities', 'aqop-leads'); ?></option>
                    <?php foreach ($types as $type): ?>
                        <option value="<?php echo esc_attr($type); ?>" <?php selected($filter_type, $type); ?>>
                            <?php echo esc_html(ucfirst(str_replace('_', ' ', $type))); ?>
                        </option>
                    <?php endforeach; ?>
                </select>

                <!-- User Filter (Simple Input for now, could be User Select) -->
                <input type="number" name="user_id" placeholder="User ID"
                    value="<?php echo $filter_user ? esc_attr($filter_user) : ''; ?>" style="width: 100px;">

                <input type="submit" class="button" value="<?php _e('Filter', 'aqop-leads'); ?>">
            </div>

            <div class="alignleft actions">
                <input type="search" name="s" value="<?php echo esc_attr($filter_search); ?>"
                    placeholder="<?php _e('Search logs...', 'aqop-leads'); ?>">
                <input type="submit" class="button" value="<?php _e('Search', 'aqop-leads'); ?>">
            </div>

            <!-- Pagination -->
            <div class="tablenav-pages">
                <span class="displaying-num"><?php echo sprintf(__('%d items', 'aqop-leads'), $total); ?></span>
                <?php
                $page_links = paginate_links(array(
                    'base' => add_query_arg('paged', '%#%'),
                    'format' => '',
                    'prev_text' => __('&laquo;'),
                    'next_text' => __('&raquo;'),
                    'total' => $total_pages,
                    'current' => $paged
                ));

                if ($page_links) {
                    echo '<span class="pagination-links">' . $page_links . '</span>';
                }
                ?>
            </div>
        </div>

        <table class="wp-list-table widefat fixed striped">
            <thead>
                <tr>
                    <th scope="col" class="manage-column column-date" style="width: 150px;">
                        <?php _e('Date', 'aqop-leads'); ?></th>
                    <th scope="col" class="manage-column column-user" style="width: 150px;">
                        <?php _e('User', 'aqop-leads'); ?></th>
                    <th scope="col" class="manage-column column-activity" style="width: 150px;">
                        <?php _e('Activity', 'aqop-leads'); ?></th>
                    <th scope="col" class="manage-column column-details"><?php _e('Details', 'aqop-leads'); ?></th>
                    <th scope="col" class="manage-column column-ip" style="width: 120px;">
                        <?php _e('IP Address', 'aqop-leads'); ?></th>
                </tr>
            </thead>
            <tbody>
                <?php if (!empty($logs)): ?>
                    <?php foreach ($logs as $log): ?>
                        <tr>
                            <td>
                                <?php echo esc_html($log->created_at); ?><br>
                                <small
                                    style="color: #999;"><?php echo human_time_diff(strtotime($log->created_at), current_time('timestamp')) . ' ago'; ?></small>
                            </td>
                            <td>
                                <strong><?php echo esc_html($log->user_name); ?></strong><br>
                                <small><a
                                        href="user-edit.php?user_id=<?php echo $log->user_id; ?>"><?php echo esc_html($log->user_email); ?></a></small>
                            </td>
                            <td>
                                <span class="badge badge-<?php echo esc_attr($log->activity_type); ?>"
                                    style="background: #e5e5e5; padding: 2px 6px; border-radius: 4px; font-size: 11px;">
                                    <?php echo esc_html(strtoupper(str_replace('_', ' ', $log->activity_type))); ?>
                                </span>
                            </td>
                            <td>
                                <?php
                                if (!empty($log->activity_details)) {
                                    echo '<pre style="margin: 0; font-size: 10px; max-height: 100px; overflow: auto;">';
                                    echo esc_html(json_encode($log->activity_details, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE));
                                    echo '</pre>';
                                } else {
                                    echo '<span style="color: #ccc;">-</span>';
                                }
                                ?>
                            </td>
                            <td>
                                <?php echo esc_html($log->ip_address); ?>
                            </td>
                        </tr>
                    <?php endforeach; ?>
                <?php else: ?>
                    <tr>
                        <td colspan="5"><?php _e('No activity logs found.', 'aqop-leads'); ?></td>
                    </tr>
                <?php endif; ?>
            </tbody>
        </table>
    </form>
</div>