<?php
/**
 * Activity Tracker Class
 *
 * Handles logging of user activities to the database.
 *
 * @package AQOP_Leads
 * @since   1.1.0
 */

if (!defined('ABSPATH')) {
    exit;
}

/**
 * AQOP_Activity_Tracker class.
 */
class AQOP_Activity_Tracker
{
    /**
     * Table name.
     *
     * @var string
     */
    private $table_name;

    /**
     * Constructor.
     */
    public function __construct()
    {
        global $wpdb;
        $this->table_name = $wpdb->prefix . 'aq_user_activity_log';
    }

    /**
     * Create database table.
     *
     * @since 1.1.0
     */
    public function install()
    {
        global $wpdb;

        $charset_collate = $wpdb->get_charset_collate();

        $sql = "CREATE TABLE $this->table_name (
			id bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT,
			user_id bigint(20) UNSIGNED NOT NULL,
			activity_type varchar(50) NOT NULL,
			activity_details longtext,
			ip_address varchar(45),
			user_agent text,
			session_id varchar(100),
			created_at datetime DEFAULT CURRENT_TIMESTAMP,
			PRIMARY KEY  (id),
			KEY user_id (user_id),
			KEY activity_type (activity_type),
			KEY created_at (created_at)
		) $charset_collate;";

        require_once ABSPATH . 'wp-admin/includes/upgrade.php';
        dbDelta($sql);
    }

    /**
     * Log an activity.
     *
     * @since 1.1.0
     * @param int    $user_id         User ID.
     * @param string $activity_type   Type of activity.
     * @param array  $activity_details Additional details (optional).
     * @param string $ip_address      IP address (optional).
     * @param string $user_agent      User agent (optional).
     * @param string $session_id      Session ID (optional).
     * @return int|false Insert ID on success, false on failure.
     */
    public function log($user_id, $activity_type, $activity_details = array(), $ip_address = '', $user_agent = '', $session_id = '')
    {
        global $wpdb;

        if (empty($user_id) || empty($activity_type)) {
            return false;
        }

        // Auto-fill IP and Agent if not provided
        if (empty($ip_address)) {
            $ip_address = $this->get_client_ip();
        }

        if (empty($user_agent)) {
            $user_agent = isset($_SERVER['HTTP_USER_AGENT']) ? sanitize_text_field($_SERVER['HTTP_USER_AGENT']) : '';
        }

        $data = array(
            'user_id' => $user_id,
            'activity_type' => sanitize_text_field($activity_type),
            'activity_details' => !empty($activity_details) ? wp_json_encode($activity_details) : null,
            'ip_address' => substr(sanitize_text_field($ip_address), 0, 45),
            'user_agent' => sanitize_text_field($user_agent),
            'session_id' => sanitize_text_field($session_id),
            'created_at' => current_time('mysql'),
        );

        $format = array('%d', '%s', '%s', '%s', '%s', '%s', '%s');

        $inserted = $wpdb->insert($this->table_name, $data, $format);

        return $inserted ? $wpdb->insert_id : false;
    }

    /**
     * Get logs.
     *
     * @since 1.1.0
     * @param array $args Filter arguments.
     * @return array Logs and total count.
     */
    public function get_logs($args = array())
    {
        global $wpdb;

        $defaults = array(
            'user_id' => 0,
            'activity_type' => '',
            'date_from' => '',
            'date_to' => '',
            'search' => '',
            'limit' => 20,
            'offset' => 0,
            'orderby' => 'created_at',
            'order' => 'DESC',
        );

        $args = wp_parse_args($args, $defaults);

        $where = array('1=1');
        $values = array();

        if (!empty($args['user_id'])) {
            $where[] = 'user_id = %d';
            $values[] = $args['user_id'];
        }

        if (!empty($args['activity_type'])) {
            $where[] = 'activity_type = %s';
            $values[] = $args['activity_type'];
        }

        if (!empty($args['date_from'])) {
            $where[] = 'created_at >= %s';
            $values[] = $args['date_from'];
        }

        if (!empty($args['date_to'])) {
            $where[] = 'created_at <= %s';
            $values[] = $args['date_to'];
        }

        if (!empty($args['search'])) {
            $search = '%' . $wpdb->esc_like($args['search']) . '%';
            $where[] = '(activity_type LIKE %s OR ip_address LIKE %s OR activity_details LIKE %s)';
            $values[] = $search;
            $values[] = $search;
            $values[] = $search;
        }

        $where_sql = implode(' AND ', $where);
        $limit = absint($args['limit']);
        $offset = absint($args['offset']);
        $orderby = sanitize_sql_orderby($args['orderby']);
        $order = strtoupper($args['order']) === 'ASC' ? 'ASC' : 'DESC';

        // Get items
        $sql = "SELECT * FROM $this->table_name WHERE $where_sql ORDER BY $orderby $order LIMIT %d OFFSET %d";
        $query_args = array_merge($values, array($limit, $offset));
        $items = $wpdb->get_results($wpdb->prepare($sql, $query_args));

        // Get total
        $count_sql = "SELECT COUNT(*) FROM $this->table_name WHERE $where_sql";
        $total = $wpdb->get_var(!empty($values) ? $wpdb->prepare($count_sql, $values) : $count_sql);

        // Process items (decode JSON)
        foreach ($items as $item) {
            $item->activity_details = json_decode($item->activity_details, true);

            // Get user data
            $user = get_userdata($item->user_id);
            $item->user_name = $user ? $user->display_name : 'Unknown User';
            $item->user_email = $user ? $user->user_email : '';
        }

        return array(
            'items' => $items,
            'total' => (int) $total,
        );
    }

    /**
     * Clear logs.
     *
     * @since 1.1.0
     * @param int $days Keep logs newer than X days (0 to clear all).
     * @return int|false Number of rows deleted.
     */
    public function cleanup($days = 90)
    {
        global $wpdb;

        if ($days > 0) {
            $date = date('Y-m-d H:i:s', strtotime("-{$days} days"));
            $sql = $wpdb->prepare("DELETE FROM $this->table_name WHERE created_at < %s", $date);
        } else {
            $sql = "TRUNCATE TABLE $this->table_name";
        }

        return $wpdb->query($sql);
    }

    /**
     * Get client IP.
     *
     * @return string
     */
    private function get_client_ip()
    {
        $ip = '';
        if (isset($_SERVER['HTTP_CLIENT_IP'])) {
            $ip = $_SERVER['HTTP_CLIENT_IP'];
        } elseif (isset($_SERVER['HTTP_X_FORWARDED_FOR'])) {
            $ip = $_SERVER['HTTP_X_FORWARDED_FOR'];
        } elseif (isset($_SERVER['REMOTE_ADDR'])) {
            $ip = $_SERVER['REMOTE_ADDR'];
        }
        return sanitize_text_field($ip);
    }
}
