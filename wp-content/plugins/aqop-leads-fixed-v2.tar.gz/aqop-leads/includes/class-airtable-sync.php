<?php
/**
 * Airtable Smart Sync functionality
 *
 * @package AQOP_Leads
 * @since 1.0.9
 */

if (!defined('ABSPATH')) {
	exit;
}

/**
 * AQOP Airtable Sync class
 */
class AQOP_Airtable_Sync
{

	/**
	 * Airtable API base URL
	 */
	const API_BASE_URL = 'https://api.airtable.com/v0/';

	/**
	 * Sync from Airtable to WordPress
	 *
	 * @return array Sync results
	 */
	public function sync_from_airtable()
	{
		// Increase execution time for large syncs
		@set_time_limit(300); // 5 minutes
		@ini_set('max_execution_time', 300);

		// Increase memory limit
		@ini_set('memory_limit', '256M');

		$results = array(
			'success' => false,
			'message' => '',
			'leads_processed' => 0,
			'leads_created' => 0,
			'leads_updated' => 0,
			'countries_created' => 0,
			'campaigns_created' => 0,
			'groups_created' => 0,
			'sources_created' => 0,
			'errors' => array(),
		);

		try {
			// Get Airtable credentials
			$api_key = get_option('aqop_airtable_token', '');
			$base_id = get_option('aqop_airtable_base_id', '');
			$table_name = get_option('aqop_airtable_table_name', '');

			if (empty($api_key) || empty($base_id) || empty($table_name)) {
				throw new Exception('Airtable credentials not configured');
			}

			// Fetch all records from Airtable
			$records = $this->fetch_airtable_records($api_key, $base_id, $table_name);

			if (empty($records)) {
				throw new Exception('No records found in Airtable');
			}

			$results['leads_processed'] = count($records);

			// Process each record
			foreach ($records as $record) {
				try {
					$this->process_airtable_record($record, $results);
				} catch (Exception $e) {
					$results['errors'][] = 'Record ' . $record['id'] . ': ' . $e->getMessage();
				}
			}

			$results['success'] = true;
			$results['message'] = sprintf(
				'Sync completed: %d leads processed, %d created, %d updated',
				$results['leads_processed'],
				$results['leads_created'],
				$results['leads_updated']
			);

			// Update last sync time
			update_option('aqop_airtable_last_sync', current_time('mysql'));
			update_option('aqop_airtable_sync_stats', $results);

		} catch (Exception $e) {
			$results['message'] = 'Sync failed: ' . $e->getMessage();
			$results['errors'][] = $e->getMessage();
		}

		return $results;
	}

	/**
	 * Fetch records from Airtable
	 *
	 * @param string $api_key API key
	 * @param string $base_id Base ID
	 * @param string $table_name Table name
	 * @return array Records
	 */
	private function fetch_airtable_records($api_key, $base_id, $table_name)
	{
		$records = array();
		$offset = '';

		do {
			$url = self::API_BASE_URL . $base_id . '/' . rawurlencode($table_name) . '?pageSize=100';
			if (!empty($offset)) {
				$url .= '&offset=' . $offset;
			}

			$response = wp_remote_get($url, array(
				'headers' => array(
					'Authorization' => 'Bearer ' . $api_key,
				),
				'timeout' => 60, // Increase from 30 to 60 seconds
			));

			if (is_wp_error($response)) {
				throw new Exception('API request failed: ' . $response->get_error_message());
			}

			$body = wp_remote_retrieve_body($response);
			$data = json_decode($body, true);

			if (json_last_error() !== JSON_ERROR_NONE) {
				throw new Exception('Invalid JSON response from Airtable');
			}

			if (isset($data['records'])) {
				$records = array_merge($records, $data['records']);
			}

			$offset = isset($data['offset']) ? $data['offset'] : '';

		} while (!empty($offset));

		return $records;
	}

	/**
	 * Process a single Airtable record
	 *
	 * @param array $record Airtable record
	 * @param array &$results Results array (passed by reference)
	 */
	private function process_airtable_record($record, &$results)
	{
		global $wpdb;

		$mapped_data = $this->map_airtable_record($record);

		if (empty($mapped_data['lead_name']) && empty($mapped_data['email'])) {
			throw new Exception('Record missing required fields (name or email)');
		}

		// Handle related entities
		if (!empty($mapped_data['country_name'])) {
			$mapped_data['country_id'] = $this->get_or_create_country($mapped_data['country_name']);
			if ($mapped_data['country_id']) {
				$results['countries_created']++;
			}
			unset($mapped_data['country_name']);
		}

		if (!empty($mapped_data['group_name'])) {
			$mapped_data['group_id'] = $this->get_or_create_campaign_group($mapped_data['group_name']);
			if ($mapped_data['group_id']) {
				$results['groups_created']++;
			}
			unset($mapped_data['group_name']);
		}

		if (!empty($mapped_data['campaign_name'])) {
			$mapped_data['campaign_id'] = $this->get_or_create_campaign(
				$mapped_data['campaign_name'],
				$mapped_data['group_id'] ?? null,
				$mapped_data['country_id'] ?? null,
				$mapped_data['platform'] ?? null
			);
			if ($mapped_data['campaign_id']) {
				$results['campaigns_created']++;
			}
			unset($mapped_data['campaign_name']);
		}

		if (!empty($mapped_data['source_name'])) {
			$mapped_data['source_id'] = $this->get_or_create_source($mapped_data['source_name']);
			if ($mapped_data['source_id']) {
				$results['sources_created']++;
			}
			unset($mapped_data['source_name']);
		}

		// Check if lead exists
		$existing_lead = null;
		if (!empty($mapped_data['email'])) {
			$existing_lead = $wpdb->get_row(
				$wpdb->prepare(
					"SELECT id FROM {$wpdb->prefix}aq_leads WHERE email = %s",
					$mapped_data['email']
				)
			);
		}

		// Get field mappings from options
		$mappings = get_option('aqop_airtable_field_mapping', array());

		// Debug: Log mappings and record data
		error_log('AQOP: Processing record ' . $record['id']);
		error_log('AQOP: Available field mappings: ' . print_r($mappings, true));
		error_log('AQOP: Record fields: ' . print_r(array_keys($record['fields']), true));

		// Build insert data array dynamically based on field mappings
		$lead_data = array();
		$lead_format = array();

		foreach ($mappings as $mapping) {
			$airtable_field = $mapping['airtable_field'];
			$wp_field = $mapping['wp_field'];

			// Skip fields that need special handling (handled by get_or_create methods)
			if (in_array($wp_field, array('country_id', 'campaign_id', 'group_id', 'source_id'), true)) {
				continue; // These are handled separately
			}

			// Get value directly from Airtable record
			if (isset($record['fields'][$airtable_field])) {
				$value = $record['fields'][$airtable_field];

				// Debug: Log field mapping
				error_log("AQOP: Mapping '{$airtable_field}' -> '{$wp_field}' = '{$value}'");

				// Handle different field types
				switch ($wp_field) {
					case 'name':
					case 'lead_name':
					case 'email':
					case 'phone':
					case 'priority':
					case 'notes':
						$lead_data[$wp_field] = sanitize_text_field($value);
						$lead_format[] = '%s';
						break;

					case 'status_id':
						$lead_data[$wp_field] = intval($value);
						$lead_format[] = '%d';
						break;

					case 'custom_data':
						$lead_data[$wp_field] = wp_json_encode($value);
						$lead_format[] = '%s';
						break;

					case 'platform':
						$lead_data[$wp_field] = sanitize_text_field($value);
						$lead_format[] = '%s';
						break;
				}
			} else {
				error_log("AQOP: Field '{$airtable_field}' not found in record");
			}
		}

		error_log('AQOP: Final lead_data: ' . print_r($lead_data, true));

		// Add the processed relational fields
		if (isset($mapped_data['country_id'])) {
			$lead_data['country_id'] = $mapped_data['country_id'];
			$lead_format[] = '%d';
		}

		if (isset($mapped_data['campaign_id'])) {
			$lead_data['campaign_id'] = $mapped_data['campaign_id'];
			$lead_format[] = '%d';
		}

		if (isset($mapped_data['group_id'])) {
			$lead_data['group_id'] = $mapped_data['group_id'];
			$lead_format[] = '%d';
		}

		if (isset($mapped_data['source_id'])) {
			$lead_data['source_id'] = $mapped_data['source_id'];
			$lead_format[] = '%d';
		}

		// Add timestamps
		$lead_data['updated_at'] = current_time('mysql');
		$lead_format[] = '%s';

		if ($existing_lead) {
			// Update existing lead
			$wpdb->update(
				$wpdb->prefix . 'aq_leads',
				$lead_data,
				array('id' => $existing_lead->id),
				$lead_format,
				array('%d')
			);
			$results['leads_updated']++;
		} else {
			// Create new lead
			$lead_data['created_at'] = current_time('mysql');
			$lead_format[] = '%s';
			$wpdb->insert(
				$wpdb->prefix . 'aq_leads',
				$lead_data,
				$lead_format
			);
			$results['leads_created']++;
		}

		// Log event
		if (class_exists('AQOP_Event_Logger')) {
			AQOP_Event_Logger::log(
				'leads',
				'airtable_sync',
				'system',
				$existing_lead ? $existing_lead->id : $wpdb->insert_id,
				array(
					'airtable_record_id' => $record['id'],
					'operation' => $existing_lead ? 'updated' : 'created',
					'mapped_fields' => array_keys($mapped_data),
				)
			);
		}
	}

	/**
	 * Get or create country by name
	 *
	 * @param string $country_name Country name
	 * @return int|null Country ID
	 */
	public function get_or_create_country($country_name)
	{
		global $wpdb;

		if (empty($country_name)) {
			return null;
		}

		$country_name = sanitize_text_field($country_name);

		// Check if exists
		$existing = $wpdb->get_var(
			$wpdb->prepare(
				"SELECT id FROM {$wpdb->prefix}aq_dim_countries WHERE country_name_en = %s",
				$country_name
			)
		);

		if ($existing) {
			return $existing;
		}

		// Create new country
		$inserted = $wpdb->insert(
			$wpdb->prefix . 'aq_dim_countries',
			array(
				'country_name_en' => $country_name,
				'country_name_ar' => $country_name, // Same for both
				'country_code' => strtoupper(substr($country_name, 0, 2)), // First 2 letters as code
			),
			array('%s', '%s', '%s')
		);

		if ($inserted) {
			return $wpdb->insert_id;
		}

		return null;
	}

	/**
	 * Get or create campaign group by name
	 *
	 * @param string $group_name Group name
	 * @return int|null Group ID
	 */
	public function get_or_create_campaign_group($group_name)
	{
		global $wpdb;

		if (empty($group_name)) {
			return null;
		}

		$group_name = sanitize_text_field($group_name);

		// Check if exists
		$existing = $wpdb->get_var(
			$wpdb->prepare(
				"SELECT id FROM {$wpdb->prefix}aq_campaign_groups WHERE group_name_en = %s",
				$group_name
			)
		);

		if ($existing) {
			return $existing;
		}

		// Create new group
		$inserted = $wpdb->insert(
			$wpdb->prefix . 'aq_campaign_groups',
			array(
				'group_name_en' => $group_name,
				'group_name_ar' => $group_name, // Same for both
				'description' => 'Auto-created from Airtable sync',
				'created_at' => current_time('mysql'),
			),
			array('%s', '%s', '%s', '%s')
		);

		if ($inserted) {
			return $wpdb->insert_id;
		}

		return null;
	}

	/**
	 * Get or create campaign by name
	 *
	 * @param string $campaign_name Campaign name
	 * @param int|null $group_id Group ID
	 * @param int|null $country_id Country ID
	 * @param string|null $platform Platform
	 * @return int|null Campaign ID
	 */
	public function get_or_create_campaign($campaign_name, $group_id = null, $country_id = null, $platform = null)
	{
		global $wpdb;

		if (empty($campaign_name)) {
			return null;
		}

		$campaign_name = sanitize_text_field($campaign_name);

		// Check if exists
		$existing = $wpdb->get_var(
			$wpdb->prepare(
				"SELECT id FROM {$wpdb->prefix}aq_leads_campaigns WHERE name = %s",
				$campaign_name
			)
		);

		if ($existing) {
			// Optional: Update country if missing? For now, just return existing.
			return $existing;
		}

		// Create new campaign
		$inserted = $wpdb->insert(
			$wpdb->prefix . 'aq_leads_campaigns',
			array(
				'group_id' => $group_id,
				'country_id' => $country_id,
				'name' => $campaign_name,
				'description' => 'Auto-created from Airtable sync',
				'platform' => $platform,
				'is_active' => 1,
				'created_at' => current_time('mysql'),
			),
			array('%d', '%d', '%s', '%s', '%s', '%d', '%s')
		);

		if ($inserted) {
			return $wpdb->insert_id;
		}

		return null;
	}

	/**
	 * Get or create source by name
	 *
	 * @param string $source_name Source name
	 * @param string $source_type Source type
	 * @return int|null Source ID
	 */
	public function get_or_create_source($source_name, $source_type = 'other')
	{
		global $wpdb;

		if (empty($source_name)) {
			return null;
		}

		$source_name = sanitize_text_field($source_name);

		// Check if exists by name or code
		$existing = $wpdb->get_var(
			$wpdb->prepare(
				"SELECT id FROM {$wpdb->prefix}aq_leads_sources WHERE source_name = %s OR source_code = %s",
				$source_name,
				sanitize_title($source_name)
			)
		);

		if ($existing) {
			return $existing;
		}

		// Create new source
		$source_code = sanitize_title($source_name);
		$inserted = $wpdb->insert(
			$wpdb->prefix . 'aq_leads_sources',
			array(
				'source_name' => $source_name,
				'source_code' => $source_code,
				'source_type' => $source_type,
				'is_active' => 1,
			),
			array('%s', '%s', '%s', '%d')
		);

		if ($inserted) {
			return $wpdb->insert_id;
		}

		return null;
	}

	/**
	 * Map Airtable record fields to WordPress fields
	 *
	 * @param array $record Airtable record
	 * @return array Mapped data
	 */
	public function map_airtable_record($record)
	{
		$mapped_data = array();
		$mappings = get_option('aqop_airtable_field_mapping', array());

		if (empty($mappings) || !isset($record['fields'])) {
			return $mapped_data;
		}

		foreach ($mappings as $mapping) {
			$airtable_field = $mapping['airtable_field'];
			$wp_field = $mapping['wp_field'];

			if (isset($record['fields'][$airtable_field])) {
				$value = $record['fields'][$airtable_field];

				// Handle different field types
				switch ($wp_field) {
					case 'name':
					case 'lead_name':
					case 'email':
					case 'phone':
					case 'notes':
					case 'priority':
						$mapped_data[$wp_field] = sanitize_text_field($value);
						break;

					case 'country_id':
						$mapped_data['country_name'] = sanitize_text_field($value);
						break;

					case 'campaign_id':
						$mapped_data['campaign_name'] = sanitize_text_field($value);
						break;

					case 'group_id':
						$mapped_data['group_name'] = sanitize_text_field($value);
						break;

					case 'source_id':
						$mapped_data['source_name'] = sanitize_text_field($value);
						break;

					case 'status_id':
						$mapped_data[$wp_field] = intval($value);
						break;

					case 'custom_data':
						$mapped_data[$wp_field] = wp_json_encode($value);
						break;

					case 'platform':
						$mapped_data[$wp_field] = sanitize_text_field($value);
						break;
				}
			}
		}

		return $mapped_data;
	}

	/**
	 * Get format array for database operations
	 *
	 * @param array $data Data array
	 * @return array Format array
	 */
	private function get_format_array($data)
	{
		$formats = array();
		foreach ($data as $key => $value) {
			switch ($key) {
				case 'country_id':
				case 'campaign_id':
				case 'source_id':
				case 'status_id':
					$formats[] = '%d';
					break;
				case 'custom_data':
					$formats[] = '%s';
					break;
				default:
					$formats[] = '%s';
					break;
			}
		}
		return $formats;
	}

	/**
	 * Get sync statistics
	 *
	 * @return array Sync stats
	 */
	public function get_sync_stats()
	{
		return get_option('aqop_airtable_sync_stats', array());
	}

	/**
	 * Get last sync time
	 *
	 * @return string Last sync time
	 */
	public function get_last_sync_time()
	{
		$last_sync = get_option('aqop_airtable_last_sync', '');
		if (empty($last_sync)) {
			return 'Never';
		}
		return date_i18n('M j, Y H:i', strtotime($last_sync));
	}

	/**
	 * Fetch field metadata from Airtable
	 *
	 * @param string $base_id Base ID
	 * @param string $table_name Table name
	 * @param string $api_key API key
	 * @return array Array of field information
	 */
	public static function fetch_airtable_fields($base_id, $table_name, $api_key)
	{
		if (empty($base_id) || empty($table_name) || empty($api_key)) {
			throw new Exception('Base ID, table name, and API key are required');
		}

		$url = self::API_BASE_URL . 'meta/bases/' . $base_id . '/tables';

		$response = wp_remote_get($url, array(
			'headers' => array(
				'Authorization' => 'Bearer ' . $api_key,
			),
			'timeout' => 60, // Increase from 30 to 60 seconds
		));

		if (is_wp_error($response)) {
			throw new Exception('API request failed: ' . $response->get_error_message());
		}

		$body = wp_remote_retrieve_body($response);
		$data = json_decode($body, true);

		if (json_last_error() !== JSON_ERROR_NONE) {
			throw new Exception('Invalid JSON response from Airtable');
		}

		// Find the requested table
		$table_fields = array();
		foreach ($data['tables'] ?? array() as $table) {
			if ($table['name'] === $table_name || $table['id'] === $table_name) {
				foreach ($table['fields'] ?? array() as $field) {
					$table_fields[] = array(
						'id' => $field['id'],
						'name' => $field['name'],
						'type' => $field['type'],
					);
				}
				break;
			}
		}

		if (empty($table_fields)) {
			throw new Exception('Table not found or no fields available');
		}

		return $table_fields;
	}
}
