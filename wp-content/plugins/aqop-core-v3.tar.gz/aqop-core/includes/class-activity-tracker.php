<?php
/**
 * Activity Tracker Class
 *
 * Tracks all user activities for monitoring and analytics.
 *
 * @package AQOP_Core
 * @since   1.0.0
 */

if (!defined('ABSPATH')) {
    exit;
}

class AQOP_Activity_Tracker
{
    /**
     * Track user action.
     *
     * @since  1.0.0
     * @param  array $data Activity data.
     * @return int|false Activity ID on success, false on failure.
     */
    public static function track_action($data)
    {
        global $wpdb;

        try {
            // Validate required fields
            if (empty($data['user_id']) || empty($data['module_code']) || empty($data['action_type'])) {
                return false;
            }

            // Get session ID if available
            $session_id = isset($data['session_id']) ? absint($data['session_id']) : self::get_current_session_id($data['user_id']);

            // Prepare activity data
            $activity_data = array(
                'session_id' => $session_id,
                'user_id' => absint($data['user_id']),
                'module_code' => sanitize_text_field($data['module_code']),
                'action_type' => sanitize_text_field($data['action_type']),
                'action_details' => isset($data['action_details']) ? sanitize_textarea_field($data['action_details']) : null,
                'page_url' => isset($data['page_url']) ? esc_url_raw($data['page_url']) : null,
                'ip_address' => isset($data['ip_address']) ? sanitize_text_field($data['ip_address']) : self::get_client_ip(),
                'created_at' => current_time('mysql'),
            );

            // Insert activity
            $inserted = $wpdb->insert(
                $wpdb->prefix . 'aq_user_activity',
                $activity_data,
                array('%d', '%d', '%s', '%s', '%s', '%s', '%s', '%s')
            );

            if (false === $inserted) {
                error_log('AQOP Activity Tracker: Failed to track action - ' . $wpdb->last_error);
                return false;
            }

            return $wpdb->insert_id;

        } catch (Exception $e) {
            error_log('AQOP Activity Tracker: ' . $e->getMessage());
            return false;
        }
    }

    /**
     * Track page view.
     *
     * @since  1.0.0
     * @param  int    $user_id User ID.
     * @param  string $module  Module code.
     * @param  string $page_url Page URL.
     * @return int|false Activity ID on success, false on failure.
     */
    public static function track_page_view($user_id, $module, $page_url)
    {
        return self::track_action(array(
            'user_id' => $user_id,
            'module_code' => $module,
            'action_type' => 'page_view',
            'page_url' => $page_url,
        ));
    }

    /**
     * Track API call.
     *
     * @since  1.0.0
     * @param  int    $user_id  User ID.
     * @param  string $endpoint API endpoint.
     * @param  string $method   HTTP method.
     * @param  array  $params   Request parameters.
     * @return int|false Activity ID on success, false on failure.
     */
    public static function track_api_call($user_id, $endpoint, $method, $params = array())
    {
        $module = self::extract_module_from_endpoint($endpoint);

        return self::track_action(array(
            'user_id' => $user_id,
            'module_code' => $module,
            'action_type' => 'api_call',
            'action_details' => json_encode(array(
                'endpoint' => $endpoint,
                'method' => $method,
                'params' => $params,
            )),
        ));
    }

    /**
     * Get user activity.
     *
     * @since  1.0.0
     * @param  int   $user_id User ID.
     * @param  array $args    Query arguments.
     * @return array Activity records.
     */
    public static function get_user_activity($user_id, $args = array())
    {
        global $wpdb;

        $defaults = array(
            'module' => null,
            'action_type' => null,
            'date_from' => null,
            'date_to' => null,
            'limit' => 100,
            'offset' => 0,
        );

        $args = wp_parse_args($args, $defaults);

        $where_clauses = array('a.user_id = %d');
        $where_values = array(absint($user_id));

        if ($args['module']) {
            $where_clauses[] = 'a.module_code = %s';
            $where_values[] = $args['module'];
        }

        if ($args['action_type']) {
            $where_clauses[] = 'a.action_type = %s';
            $where_values[] = $args['action_type'];
        }

        if ($args['date_from']) {
            $where_clauses[] = 'a.created_at >= %s';
            $where_values[] = $args['date_from'];
        }

        if ($args['date_to']) {
            $where_clauses[] = 'a.created_at <= %s';
            $where_values[] = $args['date_to'];
        }

        $where_sql = implode(' AND ', $where_clauses);

        $sql = "SELECT 
			a.*,
			u.display_name as user_name
		FROM {$wpdb->prefix}aq_user_activity a
		LEFT JOIN {$wpdb->users} u ON a.user_id = u.ID
		WHERE {$where_sql}
		ORDER BY a.created_at DESC
		LIMIT %d OFFSET %d";

        $where_values[] = absint($args['limit']);
        $where_values[] = absint($args['offset']);

        $results = $wpdb->get_results($wpdb->prepare($sql, $where_values));

        return $results ? $results : array();
    }

    /**
     * Get recent activity.
     *
     * @since  1.0.0
     * @param  array $args Query arguments.
     * @return array Activity records.
     */
    public static function get_recent_activity($args = array())
    {
        global $wpdb;

        $defaults = array(
            'module' => null,
            'limit' => 50,
        );

        $args = wp_parse_args($args, $defaults);

        $where_clauses = array();
        $where_values = array();

        if ($args['module']) {
            $where_clauses[] = 'a.module_code = %s';
            $where_values[] = $args['module'];
        }

        $where_sql = !empty($where_clauses) ? 'WHERE ' . implode(' AND ', $where_clauses) : '';

        $sql = "SELECT 
			a.*,
			u.display_name as user_name,
			u.user_email
		FROM {$wpdb->prefix}aq_user_activity a
		LEFT JOIN {$wpdb->users} u ON a.user_id = u.ID
		{$where_sql}
		ORDER BY a.created_at DESC
		LIMIT %d";

        $where_values[] = absint($args['limit']);

        $results = $wpdb->get_results($wpdb->prepare($sql, $where_values));

        return $results ? $results : array();
    }

    /**
     * Get current session ID for user.
     *
     * @since  1.0.0
     * @param  int $user_id User ID.
     * @return int|null Session ID or null.
     */
    private static function get_current_session_id($user_id)
    {
        global $wpdb;

        $session = $wpdb->get_var(
            $wpdb->prepare(
                "SELECT id FROM {$wpdb->prefix}aq_user_sessions 
				WHERE user_id = %d 
				AND is_active = 1 
				ORDER BY last_activity DESC 
				LIMIT 1",
                absint($user_id)
            )
        );

        return $session ? absint($session) : null;
    }

    /**
     * Extract module from API endpoint.
     *
     * @since  1.0.0
     * @param  string $endpoint API endpoint.
     * @return string Module code.
     */
    private static function extract_module_from_endpoint($endpoint)
    {
        // Extract module from endpoint like /aqop/v1/leads/123
        if (preg_match('/\/aqop\/v1\/([^\/]+)/', $endpoint, $matches)) {
            return $matches[1];
        }

        return 'core';
    }

    /**
     * Get client IP address.
     *
     * @since  1.0.0
     * @return string IP address.
     */
    private static function get_client_ip()
    {
        $ip = '';

        if (!empty($_SERVER['HTTP_CLIENT_IP'])) {
            $ip = $_SERVER['HTTP_CLIENT_IP'];
        } elseif (!empty($_SERVER['HTTP_X_FORWARDED_FOR'])) {
            $ip = $_SERVER['HTTP_X_FORWARDED_FOR'];
        } else {
            $ip = $_SERVER['REMOTE_ADDR'];
        }

        return sanitize_text_field($ip);
    }
}
